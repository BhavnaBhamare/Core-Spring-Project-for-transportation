package com.data.core.spring.project;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class InsideMapper implements RowMapper<Inside> {
	public Inside mapRow(ResultSet rs, int rowNum) throws SQLException {
		Inside inside = new Inside();
		inside.setId(rs.getInt("id"));
		inside.setName(rs.getString("name"));
		inside.setDistance(rs.getString("distance"));

		return inside;
	}
}
