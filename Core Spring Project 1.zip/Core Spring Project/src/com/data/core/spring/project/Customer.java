package com.data.core.spring.project;

public class Customer {
	private Integer id;
	private String name;
	private String aadhar;
	private String mobile;
	private String copassengers;
	private String city;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAadhar() {
		return aadhar;
	}

	public void setAadhar(String aadhar) {
		this.aadhar = aadhar;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getCopassengers() {
		return copassengers;
	}

	public void setCopassengers(String copassengers) {
		this.copassengers = copassengers;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

}
