package com.data.core.spring.project;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

public class CustomerJDBCTemplate implements CustomerDao {
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;

	@Override
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	}

	@Override
	public void create(String name, String aadhar, String mobile, String copassengers, String city) {
		String SQL = "insert into customer (name, aadhar, mobile, copassengers, city) values (?, ?, ?, ?, ?)";
		jdbcTemplateObject.update(SQL, name, aadhar, mobile, copassengers, city);
		System.out.println("Created Record Name = " + name + " Aadhar = " + aadhar + " Mobile = " + mobile
				+ " Co-Passengers = " + copassengers + " City = " + city);
		return;
	}

	@Override
	public Customer getCustomer(Integer id) {
		String SQL = "select * from Customer where id = ?";
		Customer cust = jdbcTemplateObject.queryForObject(SQL, new Object[] { id }, new CustomerMapper());

		return cust;
	}

	@Override
	public List<Customer> listCustomer() {
		String SQL = "select * from Customer";
		List<Customer> cust = jdbcTemplateObject.query(SQL, new CustomerMapper());
		return cust;
	}

	@Override
	public void delete(Integer id) {
		String SQL = "delete from Customer where id = ?";
		jdbcTemplateObject.update(SQL, id);
		System.out.println("Deleted Record with ID = " + id);
		return;
	}

	@Override
	public void update(Integer id, String name, String aadhar, String mobile, String copassengers, String city) {
		String SQL = "update Customer set age = ? where id = ?";
		jdbcTemplateObject.update(SQL, name, aadhar, mobile, copassengers, city, id);
		System.out.println("Updated Record with ID = " + id);
		return;
	}

}
