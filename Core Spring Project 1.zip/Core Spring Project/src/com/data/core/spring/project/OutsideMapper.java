package com.data.core.spring.project;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class OutsideMapper implements RowMapper<Outside> {
	public Outside mapRow(ResultSet rs, int rowNum) throws SQLException {
		Outside outside = new Outside();
		outside.setId(rs.getInt("id"));
		outside.setName(rs.getString("name"));
		outside.setDistance(rs.getString("distance"));

		return outside;
	}
}
