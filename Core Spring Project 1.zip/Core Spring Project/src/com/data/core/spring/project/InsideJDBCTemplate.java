package com.data.core.spring.project;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

public class InsideJDBCTemplate implements InsideDao {
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;

	@Override
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	}

	@Override
	public void create(String name, String distance) {
		String SQL = "insert into Inside (name, distance) values (?, ?)";
		jdbcTemplateObject.update(SQL, name, distance);
		System.out.println("Created Record Name = " + name + " Distance = " + distance);
		return;
	}

	@Override
	public Inside getCustomer(Integer id) {
		String SQL = "select * from Inside where id = ?";
		Inside inside = jdbcTemplateObject.queryForObject(SQL, new Object[] { id }, new InsideMapper());
		return inside;
	}

	@Override
	public List<Inside> listInside() {
		String SQL = "select * from Inside";
		List<Inside> inside = jdbcTemplateObject.query(SQL, new InsideMapper());
		return inside;
	}

	@Override
	public void delete(Integer id) {
		String SQL = "delete from Inside where id = ?";
		jdbcTemplateObject.update(SQL, id);
		System.out.println("Deleted Record with ID = " + id);
		return;
	}

	@Override
	public void update(Integer id, String name, String distance) {
		String SQL = "update Inside set age = ? where id = ?";
		jdbcTemplateObject.update(SQL, name, distance, id);
		System.out.println("Updated Record with ID = " + id);
		return;
	}

}
