package com.data.core.spring.project;

import java.util.List;

import javax.sql.DataSource;

public interface InsideDao {
	
	public void setDataSource(DataSource ds);

	public void create(String name, String distance);

	public Inside getCustomer(Integer id);

	public List<Inside> listInside();

	public void delete(Integer id);

	public void update(Integer id, String name, String distance);
}
