package com.data.core.spring.project;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class CustomerMapper implements RowMapper<Customer> {
	public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
		Customer cust = new Customer();
		cust.setId(rs.getInt("id"));
		cust.setName(rs.getString("name"));
		cust.setAadhar(rs.getString("aadhar"));
		cust.setMobile(rs.getString("mobile"));
		cust.setCopassengers(rs.getString("copassengers"));
		cust.setCity(rs.getString("city"));

		return cust;
	}
}
