package com.data.core.spring.project;

import java.util.List;

import javax.sql.DataSource;

public interface OutsideDao {

	public void setDataSource(DataSource ds);

	public void create(String name, String distance);

	public Outside getOutside(Integer id);

	public List<Outside> listOutside();

	public void delete(Integer id);

	public void update(Integer id, String name, String distance);
}
