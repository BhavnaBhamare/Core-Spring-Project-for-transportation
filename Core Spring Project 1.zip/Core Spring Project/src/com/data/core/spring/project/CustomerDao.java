package com.data.core.spring.project;

import java.util.List;
import javax.sql.DataSource;

public interface CustomerDao {

	public void setDataSource(DataSource ds);

	public void create(String name, String aadhar, String mobile, String copassengers, String city);

	public Customer getCustomer(Integer id);

	public List<Customer> listCustomer();

	public void delete(Integer id);
	
	public void update(Integer id, String name, String aadhar, String mobile, String copassengers, String city);
}
